Installation instructions
=========================

Here you have:
- A folder named pdi_labs with the transformation files developed in chapter 7
- A folder named pdi_files with sample files for the tutorials of chapter 7
- A kettle.properties file


Installation
============
- Copy pdi_labs to your drive (c:/ or /<your_dir>/)
- Copy the folder pdi_files to /<your_dir>/ or c:/
- Edit the kettle.properties and uncomment the lines corresponding to your operating system
- Overwrite the kettle.properties file located in
	<your_dir>/.kettle/
or
	c:/Documents and Settings/your_dir/.kettle/
  with this file.

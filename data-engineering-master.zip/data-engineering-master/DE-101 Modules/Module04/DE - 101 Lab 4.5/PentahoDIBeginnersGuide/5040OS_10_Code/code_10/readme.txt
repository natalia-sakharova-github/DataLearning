Installation instructions
=========================

Here you have:
- A folder named pdi_labs with the job and transformation files developed in chapter 10
- A kettle.properties file


Installation
============
- Copy pdi_labs to your drive (c:/ or /<your_dir>/)
- Edit the kettle.properties and uncomment the lines corresponding to your operating system
- Overwrite the kettle.properties file located in
	<your_dir>/.kettle/
or
	c:/Documents and Settings/your_dir/.kettle/
  with this file.
